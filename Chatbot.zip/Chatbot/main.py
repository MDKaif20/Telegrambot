from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
import json

# -----------------------------
# Load resources (exams + notes)
# -----------------------------
with open("resources.json", "r") as f:
    resources = json.load(f)

# -----------------------------
# /start command
# -----------------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📘 Govt Exam Papers", callback_data="exams")],
        [InlineKeyboardButton("💻 Programming Notes", callback_data="notes")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("👋 Welcome! What do you want?", reply_markup=reply_markup)

# -----------------------------
# Handle menu navigation
# -----------------------------
async def menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    choice = query.data

    # Exams Section
    if choice == "exams":
        keyboard = [[InlineKeyboardButton(exam, callback_data=f"exam_{exam}")]
                    for exam in resources["exams"].keys()]
        await query.edit_message_text("📘 Select an Exam:", reply_markup=InlineKeyboardMarkup(keyboard))

    # Notes Section
    elif choice == "notes":
        keyboard = [[InlineKeyboardButton(lang, callback_data=f"note_{lang}")]
                    for lang in resources["notes"].keys()]
        await query.edit_message_text("💻 Select a Programming Language:", reply_markup=InlineKeyboardMarkup(keyboard))

    # Show Exam Papers
    elif choice.startswith("exam_"):
        exam = choice.split("_", 1)[1]
        reply = f"📘 {exam} Papers:\n"
        for year, link in resources["exams"][exam].items():
            reply += f"📂 {year}: {link}\n"
        await query.edit_message_text(reply)

    # Show Notes
    elif choice.startswith("note_"):
        lang = choice.split("_", 1)[1]
        link = resources["notes"][lang]
        await query.edit_message_text(f"💻 {lang} Notes:\n🔗 {link}")

# -----------------------------
# Main function
# -----------------------------
def main():
    # Replace with your actual BotFather token
    BOT_TOKEN = "8089407229:AAHfJs6PUwt9sCLrJ1JxngnR3WhZi2olKAI"

    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(menu_handler))

    print("✅ Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
